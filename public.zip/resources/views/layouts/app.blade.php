<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'AutoFlow') }}</title>
    <link rel="icon" type="image/png" href="{{ asset('favicon.png') }}">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
    <link rel="stylesheet" href="{{ asset('css/autoflow.css') }}">
    <link rel="stylesheet" href="{{ asset('css/app/layout.css') }}">
    <link rel="stylesheet" href="{{ asset('css/app/swal-theme.css') }}">
    @vite(['resources/css/app.css', 'resources/js/app.js'])
    <meta name="flash-success" content="{{ session('success') }}">
    <meta name="flash-error" content="{{ session('error') }}">
    @stack('styles')
</head>

<body>
    <div class="af-app">
        <aside class="af-sidebar" id="af-sidebar">
            <a href="{{ route('dashboard') }}" class="af-sidebar__brand">
                <span class="af-logo-icon">
                    <span class="af-logo-sq af-logo-sq-1"></span>
                    <span class="af-logo-sq af-logo-sq-2"></span>
                    <span class="af-logo-sq af-logo-sq-3"></span>
                </span>
                <span class="af-sidebar__brand-text">AutoFlow</span>
            </a>
            <x-nav-link>
                <div class="af-sidebar__footer">
                    <div class="af-user-pill" id="af-user-dropdown-trigger">
                        <div class="af-avatar">{{ strtoupper(substr(Auth::user()->name, 0, 2)) }}</div>
                        <div class="af-user-info">
                            <div class="af-user-info__name">{{ Auth::user()->name }}</div>
                            <div class="af-user-info__email">{{ Auth::user()->email }}</div>
                        </div>
                        <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="#94a3b8" stroke-width="2">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M19 9l-7 7-7-7" />
                        </svg>
                    </div>
                    <div class="af-dropdown__menu af-dropdown__menu--above" id="af-user-dropdown">
                        <a href="{{ route('profile.edit') }}" class="af-dropdown__menu-item">
                            <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                <path stroke-linecap="round" stroke-linejoin="round" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                            </svg>
                            Mi Perfil
                        </a>
                        <div class="af-dropdown__divider"></div>
                        <form method="POST" action="{{ route('logout') }}">
                            @csrf
                            <button type="submit" class="af-dropdown__menu-item af-dropdown__menu-item--danger">
                                <svg width="15" height="15" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                                    <path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                                </svg>
                                Cerrar sesión
                            </button>
                        </form>
                    </div>
                </div>
        </aside>
        <div class="af-overlay" id="af-overlay"></div>
        <main class="af-main">
            <header class="af-topbar">
                <button class="af-sidebar-toggle" id="af-sidebar-toggle" aria-label="Abrir menú">
                    <svg width="22" height="22" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M4 6h16M4 12h16M4 18h16" />
                    </svg>
                </button>
                @isset($breadcrumb)
                <nav class="af-topbar__breadcrumb" aria-label="Breadcrumb">{{ $breadcrumb }}</nav>
                @endisset
                <div class="af-topbar__spacer"></div>
                <div class="af-topbar__actions">
                    <a href="{{ route('automations.create') }}" class="af-btn af-btn--primary af-btn--sm af-hidden" id="af-topbar-new-btn">
                        <svg width="14" height="14" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2.5">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4" />
                        </svg>
                        Nueva
                    </a>
                    <button class="af-topbar__icon-btn" aria-label="Notificaciones">
                        <svg width="17" height="17" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="1.8">
                            <path stroke-linecap="round" stroke-linejoin="round" d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                        </svg>
                        <span class="af-notif-dot"></span>
                    </button>
                </div>
            </header>
            <div class="af-content">
                @if (session('success'))
                <div class="af-alert af-alert--success" role="alert">
                    <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M5 13l4 4L19 7" />
                    </svg>
                    {{ session('success') }}
                </div>
                @endif
                @if (session('error'))
                <div class="af-alert af-alert--danger" role="alert">
                    <svg width="16" height="16" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                        <path stroke-linecap="round" stroke-linejoin="round" d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    {{ session('error') }}
                </div>
                @endif
                {{ $slot }}
            </div>
        </main>
    </div>
    <script src="{{ asset('js/app/layout.js') }}"></script>
    @stack('scripts')
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="{{ asset('js/app/swal-flash.js') }}"></script>
</body>

</html>